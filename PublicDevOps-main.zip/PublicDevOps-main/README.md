# PublicDevOps
Public repo for files related to Azure DevOps Videos

# Azure DevOps and Bicep Pipelines
Files used for Azure DevOps and Bicep Pipelines Video
https://youtu.be/Q2HZdwTAWG0

# Azure DevOps and Terraform Pipelines
Files used for Azure DevOps and Terraform Pipelines Video
https://youtu.be/d85-KD9stqc

# Image Builder Pipeline
Files used for Azure DevOps and Image Builder
https://youtu.be/zL0eLEl2BxI

# Session Host Pipeline
Files used to deploy Session Hosts with Azure Devops
https://youtu.be/bZy6Yay0ybM

# RestartandUpdateCustomization.txt
Resources for the Image Builder deployment template to add the restart and update customization. 

Files in this repo are for meant as examples and for demonstration purposes only.
